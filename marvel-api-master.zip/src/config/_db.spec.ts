import { connect, connection } from 'mongoose';
import Story from '../modules/characters/mongoose/schemas/storie';
import Characters from '../modules/characters/mongoose/schemas/character';
import Comic from '../modules/characters/mongoose/schemas/comic';
import Event from '../modules/characters/mongoose/schemas/event';
import Serie from '../modules/characters/mongoose/schemas/serie';

describe('DB CRUD', () => {
    it('it should be ok', () => {
        const response = 'ok';

        expect(response).toEqual('ok');
    });

    beforeAll(async () => {
        await connect(`mongodb://localhost:27017/marvel`, {
            useNewUrlParser: true,
            useUnifiedTopology: true,
            useCreateIndex: true,
            useFindAndModify: false,
        });
    });

    afterAll(async () => {
        await connection.close();
    });

    it('it should insert characters', async () => {
        const comic_10223 = await Comic.create({
            id: '10223',
            digitalId: 0,
            title: 'Marvel Premiere (1972) #35',
            issueNumber: 35,
            variantDescription: '',
            description: null,
            modified: '-0001-11-30T00:00:00-0500',
            isbn: '',
            upc: '',
            diamondCode: '',
            ean: '',
            issn: '',
            format: 'Comic',
            pageCount: 36,
            textObjects: [],
            resourceURI: 'http://gateway.marvel.com/v1/public/comics/10223',
            urls: [
                {
                    type: 'detail',
                    url:
                        'http://marvel.com/comics/issue/10223/marvel_premiere_1972_35?utm_campaign=apiRef&utm_source=20dff8ea94819166f73451e4f740fe96',
                },
            ],
            series: {},
            variants: [],
            collections: [],
            collectedIssues: [],
            dates: [
                {
                    type: 'onsaleDate',
                    date: '1977-04-01T00:00:00-0500',
                },
                {
                    type: 'focDate',
                    date: '-0001-11-30T00:00:00-0500',
                },
            ],
            prices: [
                {
                    type: 'printPrice',
                    price: 0,
                },
            ],
            thumbnail: {
                path: 'http://i.annihil.us/u/prod/marvel/i/mg/b/40/image_not_available',
                extension: 'jpg',
            },
            images: [],
            creators: {
                available: 5,
                collectionURI: 'http://gateway.marvel.com/v1/public/comics/10223/creators',
                items: [
                    {
                        resourceURI: 'http://gateway.marvel.com/v1/public/creators/1746',
                        name: 'John Costanza',
                        role: 'letterer',
                    },
                    {
                        resourceURI: 'http://gateway.marvel.com/v1/public/creators/1220',
                        name: 'Jim Craig',
                        role: 'penciler',
                    },
                    {
                        resourceURI: 'http://gateway.marvel.com/v1/public/creators/13094',
                        name: 'Dave Hunt',
                        role: 'inker',
                    },
                    {
                        resourceURI: 'http://gateway.marvel.com/v1/public/creators/10105',
                        name: 'Jorge Maese',
                        role: 'colorist',
                    },
                    {
                        resourceURI: 'http://gateway.marvel.com/v1/public/creators/2909',
                        name: 'Roy Thomas',
                        role: 'writer',
                    },
                ],
                returned: 5,
            },
            characters: {},
            stories: {},
            events: {},
        });

        const event_269 = await Event.create({
            id: 269,
            title: 'Secret Invasion',
            description:
                "The shape-shifting Skrulls have been infiltrating the Earth for years, replacing many of Marvel's heroes with impostors, setting the stage for an all-out invasion.",
            resourceURI: 'http://gateway.marvel.com/v1/public/events/269',
            urls: [
                {
                    type: 'detail',
                    url:
                        'http://marvel.com/comics/events/269/secret_invasion?utm_campaign=apiRef&utm_source=20dff8ea94819166f73451e4f740fe96',
                },
                {
                    type: 'wiki',
                    url:
                        'http://marvel.com/universe/Secret_Invasion?utm_campaign=apiRef&utm_source=20dff8ea94819166f73451e4f740fe96',
                },
            ],
            modified: '2015-01-20T14:58:35-0500',
            start: '2008-06-02 00:00:00',
            end: '2009-01-25 00:00:00',
            thumbnail: {
                path: 'http://i.annihil.us/u/prod/marvel/i/mg/6/70/51ca1749980ae',
                extension: 'jpg',
            },
            creators: {},
            characters: {},
            stories: {},
            comics: {},
            series: {},
            next: {
                resourceURI: 'http://gateway.marvel.com/v1/public/events/318',
                name: 'Dark Reign',
            },
            previous: {
                resourceURI: 'http://gateway.marvel.com/v1/public/events/299',
                name: 'Messiah CompleX',
            },
        });

        const series_2045 = await Serie.create({
            id: 2045,
            title: 'Marvel Premiere (1972 - 1981)',
            description: null,
            resourceURI: 'http://gateway.marvel.com/v1/public/series/2045',
            urls: [
                {
                    type: 'detail',
                    url:
                        'http://marvel.com/comics/series/2045/marvel_premiere_1972_-_1981?utm_campaign=apiRef&utm_source=20dff8ea94819166f73451e4f740fe96',
                },
            ],
            startYear: 1972,
            endYear: 1981,
            rating: '',
            type: '',
            modified: '2018-03-01T13:17:00-0500',
            thumbnail: {
                path: 'http://i.annihil.us/u/prod/marvel/i/mg/4/40/5a98437953d4e',
                extension: 'jpg',
            },
            creators: {},
            characters: {},
            stories: {},
            comics: {},
            events: {},
            next: null,
            previous: null,
        });

        const story_19947 = await Story.create({
            id: '19947',
            title: 'Cover #19947',
            description: '',
            resourceURI: 'http://gateway.marvel.com/v1/public/stories/19947',
            type: 'cover',
            modified: '1969-12-31T19:00:00-0500',
            thumbnail: null,
            creators: {
                available: 0,
                collectionURI: 'http://gateway.marvel.com/v1/public/stories/19947/creators',
                items: [],
                returned: 0,
            },
            characters: {},
            series: {},
            comics: {},
            events: {},
            originalIssue: {
                resourceURI: 'http://gateway.marvel.com/v1/public/comics/10223',
                name: 'Marvel Premiere (1972) #35',
            },
        });

        const characters_1011334 = await Characters.create({
            id: '1011334',
            name: '3-D Man',
            description: '',
            modified: '2014-04-29T14:18:17-0400',
            thumbnail: {
                path: 'http://i.annihil.us/u/prod/marvel/i/mg/c/e0/535fecbbb9784',
                extension: 'jpg',
            },
            resourceURI: 'http://gateway.marvel.com/v1/public/characters/1011334',
            comics: {},
            series: {},
            stories: {},
            events: {},
            urls: [
                {
                    type: 'detail',
                    url:
                        'http://marvel.com/comics/characters/1011334/3-d_man?utm_campaign=apiRef&utm_source=20dff8ea94819166f73451e4f740fe96',
                },
                {
                    type: 'wiki',
                    url:
                        'http://marvel.com/universe/3-D_Man_(Chandler)?utm_campaign=apiRef&utm_source=20dff8ea94819166f73451e4f740fe96',
                },
                {
                    type: 'comiclink',
                    url:
                        'http://marvel.com/comics/characters/1011334/3-d_man?utm_campaign=apiRef&utm_source=20dff8ea94819166f73451e4f740fe96',
                },
            ],
        });

        await Comic.findOneAndUpdate(
            { _id: comic_10223._id },
            {
                characters: [
                    {
                        resourceURI: characters_1011334.resourceURI,
                        name: characters_1011334.name,
                    },
                ],
                stories: [
                    {
                        resourceURI: story_19947.resourceURI,
                        name: story_19947.title,
                        type: story_19947.type,
                    },
                ],
                series: {
                    resourceURI: series_2045.resourceURI,
                    name: series_2045.name,
                },
            },
            { upsert: true },
        );

        await Event.findByIdAndUpdate(
            { _id: event_269._id },
            {
                characters: [
                    {
                        resourceURI: characters_1011334.resourceURI,
                        name: characters_1011334.name,
                    },
                ],
                stories: [
                    {
                        resourceURI: story_19947.resourceURI,
                        name: story_19947.title,
                        type: story_19947.type,
                    },
                ],
                series: {
                    resourceURI: series_2045.resourceURI,
                    name: series_2045.name,
                },
            },
            { upsert: true },
        );

        expect(200).toBe(200);
    });
});
