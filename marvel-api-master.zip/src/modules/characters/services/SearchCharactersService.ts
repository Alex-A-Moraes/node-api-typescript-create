import Characters, { CharactersDocument } from '../mongoose/schemas/character';
import '../mongoose/schemas/storie';
import { Filter } from '../../../util';

interface Request {
    charactersId?: number;
    name?: string;
    comics?: string;
    series?: string;
    events?: string;
    stories?: string;
    limit?: number;
    offset?: number;
}

interface Response {
    offset: number;
    limit: number;
    total: number;
    count: number;
    results: CharactersDocument[];
}

const ResponseCharacters = (param: any) => {
    return {
        id: Number(param.id),
        name: param.name,
        description: param.description,
        modified: param.modified,
        thumbnail: param.thumbnail,
        resourceURI: param.resourceURI,
        stories: {
            available: Number(param.stories.length),
            collectionURI: `http://gateway.marvel.com/v1/public/characters/${param.id}/stories`,
            items: storiesList(param),
            returned: Number(param.stories.length),
        },
        urls: param.urls,
    };
};

const storiesList = (param: any) => {
    return param.stories.map((i: any) => {
        return {
            resourceURI: i.resourceURI,
            name: i.title,
            type: i.type,
        };
    });
};

class SearchCharactersService {
    async execute({
        charactersId,
        name,
        comics,
        series,
        events,
        stories,
        limit,
        offset,
    }: Request): Promise<Response> {
        const filtersArray = [];
        filtersArray.push(Filter('id', charactersId));
        filtersArray.push(Filter('name', name));
        const filter = { $and: filtersArray };

        const charactersResult = await Characters.find(filter).limit(limit).skip(offset);

        const results = charactersResult.reduce((prev: any, curr: any) => {
            prev.push(ResponseCharacters(curr));
            return prev;
        }, []);

        return {
            offset,
            limit,
            total: charactersResult.length,
            count: charactersResult.length,
            results,
        };
    }
}

export default new SearchCharactersService();
