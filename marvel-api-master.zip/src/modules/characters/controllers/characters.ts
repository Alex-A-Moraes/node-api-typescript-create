import { Request, Response } from 'express';
import httpStatus from 'http-status';
import SearchCharactersService from '../services/SearchCharactersService';
import { SendResponse } from '../../../util';

export default class CharactersController {
    static getCharacters = async (req: Request, res: Response) => {
        const {
            charactersId = null,
            offset = 0,
            limit = 20,
            stories = null,
            events = null,
            series = null,
            comics = null,
            name = null,
        } = { ...req.query, ...req.params };

        const data = await SearchCharactersService.execute({
            charactersId,
            stories,
            events,
            series,
            comics,
            name,
            offset,
            limit,
        });

        SendResponse(res, httpStatus.OK, data);
    };

    static getByStories = async (req: Request, res: Response) => {
        const {
            name = null,
            comics = null,
            series = null,
            events = null,
            stories = null,
            charactersId = null,
        } = {
            ...req.params,
            ...req.query,
        };

        let filtersArray = [];
        filtersArray.push(Filter('id', charactersId));
        let filter = { $and: filtersArray };

        const storyResult = await Story.findOne(filter).populate('comics');

        return res.status(httpStatus.OK).json(storyResult);
    };
}
