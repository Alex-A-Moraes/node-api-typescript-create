import mongoose, { Document, Schema, Model } from 'mongoose';
import { ComicDocument } from './comic';
import { SeriesDocument } from './serie';
import { StoriesDocument } from './storie';
import { EventsDocument } from './event';

export type CharactersDocument = Document & {
    id: string;
    name: string;
    description: string;
    modified: string;
    thumbnail: object;
    resourceURI: string;
    comics: ComicDocument[];
    series: SeriesDocument[];
    stories: StoriesDocument[];
    events: EventsDocument[];
    urls: string[];
};

type CharactersModel = Model<CharactersDocument>;

const CharactersSchema = new Schema({
    id: String,
    name: String,
    description: String,
    modified: String,
    thumbnail: Object,
    resourceURI: String,
    comics: Array,
    series: Array,
    stories: Array,
    events: Array,
    urls: Array,
});

export default mongoose.model<CharactersDocument, CharactersModel>('characters', CharactersSchema);
