import mongoose, { Document, Schema, Model } from 'mongoose';
import { CharactersDocument } from './character';
import { SeriesDocument } from './serie';
import { EventsDocument } from './event';
import { StoriesDocument } from './storie';

export type ComicDocument = Document & {
    id: string;
    digitalId: string;
    title: string;
    issueNumber: string;
    variantDescription: string;
    description: string;
    modified: string;
    isbn: string;
    upc: string;
    diamondCode: string;
    ean: string;
    issn: string;
    format: string;
    pageCount: number;
    textObjects: string[];
    resourceURI: string;
    urls: string[];
    series: SeriesDocument;
    variants: string[];
    collections: string[];
    collectedIssues: string[];
    dates: string[];
    prices: string[];
    thumbnail: string[];
    images: string[];
    creators: string[];
    characters: CharactersDocument[];
    stories: StoriesDocument[];
    events: EventsDocument[];
};

type ComicModel = Model<ComicDocument>;

const ComicSchema = new Schema({
    id: String,
    digitalId: String,
    title: String,
    issueNumber: String,
    variantDescription: String,
    description: String,
    modified: String,
    isbn: String,
    upc: String,
    diamondCode: String,
    ean: String,
    issn: String,
    format: String,
    pageCount: Number,
    textObjects: Array,
    resourceURI: String,
    urls: Array,
    series: Object,
    variants: Array,
    collections: Array,
    collectedIssues: Array,
    dates: Array,
    prices: Array,
    thumbnail: Array,
    images: Array,
    creators: Array,
    characters: Array,
    stories: Array,
    events: Array,
});

export default mongoose.model<ComicDocument, ComicModel>('comic', ComicSchema);
