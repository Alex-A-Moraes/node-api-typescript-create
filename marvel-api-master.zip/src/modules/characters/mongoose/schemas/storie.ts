import mongoose, { Document, Schema, Model } from 'mongoose';
import { ComicDocument } from './comic';
import { SeriesDocument } from './serie';
import { EventsDocument } from './event';
import { CharactersDocument } from './character';

export type StoriesDocument = Document & {
    id: string;
    title: string;
    description: string;
    resourceURI: string;
    type: string;
    modified: string;
    thumbnail: string[];
    comics: ComicDocument[];
    series: SeriesDocument[];
    events: EventsDocument[];
    characters: CharactersDocument[];
    creators: string[];
    originalissue: object;
};

type StoriesModel = Model<StoriesDocument>;

const StoriesSchema = new Schema({
    id: String,
    title: String,
    description: String,
    resourceURI: String,
    type: String,
    modified: String,
    thumbnail: Array,
    comics: Array,
    series: Array,
    events: Array,
    characters: Array,
    creators: Array,
    originalissue: Object,
});

export default mongoose.model<StoriesDocument, StoriesModel>('stories', StoriesSchema);
