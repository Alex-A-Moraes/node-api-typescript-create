# Umbriel

Batch mailing with Node.js & Amazon SES.
