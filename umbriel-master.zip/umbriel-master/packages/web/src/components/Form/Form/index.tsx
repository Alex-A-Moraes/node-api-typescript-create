import styled from 'styled-components';
import { Form } from '@unform/web';

export default styled(Form)`
  button {
    display: block;
    width: 100%;
  }
`;
