import { createBrowserHistory, History } from 'history';

const history: History = createBrowserHistory();

export default history;
