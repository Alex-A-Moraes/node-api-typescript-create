import { Router } from 'express';
import CharactersController from '../controllers/characters';

const charactersRouter = Router();

charactersRouter.get('/', CharactersController.find);
charactersRouter.get('/:charactersId', CharactersController.find);

export default charactersRouter;
