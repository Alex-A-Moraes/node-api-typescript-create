# API Marvel

> API de catalogo dos personagens da marvel.

### Configuração

```bash
npm install
```

### Desenvolvimento com ts-node-dev

```bash
npm run dev
```

### Executar testes automatizados

```bash
npm t
```

## Swagger

Acessar `http://localhost:3001/swagger/` documentação em Swagger-UI
