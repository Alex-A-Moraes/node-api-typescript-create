import App from '../src/app';
import request from 'supertest';
import { connect, connection } from 'mongoose';
import Characters from '../src/models/characters';

describe('Test Characters DataBase', () => {
    beforeAll(async () => {
        await connect(`mongodb://127.0.0.1:27017/marvel`);
        connection
            .once('open', () => console.log('MongoDB'))
            .on('error', (error) => console.log('Got an error', error));
    });

    afterAll(async () => {
        await connection.close();
    });

    it('it should return all characters', async () => {
        const charactersResult = await Characters.find({});

        expect(charactersResult).toEqual(
            expect.arrayContaining([expect.objectContaining({ name: '3-D Man' })]),
        );
    });

    it('it should return characters by query', async () => {
        const charactersResult = await Characters.find({ id: '1009144' });

        expect(charactersResult).toEqual(
            expect.arrayContaining([expect.objectContaining({ name: 'A.I.M.' })]),
        );
    });
});

describe('Test Characters API', () => {
    it('it should return all characters', async () => {
        const charactersResponse = await request(App.app).get('/v1/public/characters');
        expect(charactersResponse).toEqual(
            expect.arrayContaining([expect.objectContaining({ name: '3-D Man' })]),
        );
        expect(charactersResponse.status).toBe(200);
    });

    it('it should return characters  by name', async () => {
        const charactersResponse = await request(App.app).get('/v1/public/characters?name=Abyss');
        expect(charactersResponse.status).toBe(200);
        expect(charactersResponse.body).toEqual(
            expect.arrayContaining([expect.objectContaining({ name: 'Abyss' })]),
        );
    });
});
